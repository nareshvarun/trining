console.log("Hello Variables");
